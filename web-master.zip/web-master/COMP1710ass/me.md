I'm Zhiyuan Chen, a Chinese student from Lanzhou.

Lanzhou is a second-tier city in China, and are famous of it's Beef Lamian 
https://en.wikipedia.org/wiki/Beef_noodle_soup#Clear_Broth_Beef_Noodles, 
and the beautiful and unique Danxia landform

